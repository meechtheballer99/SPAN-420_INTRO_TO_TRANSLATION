# en-es-en-Dic
Spanish-English and English-Spanish pretty printed XML dictionaries. 

There are also "verbs only" dictionaries. 

\<l\> means letter, \<w\> word, \<c\> concept, \<d\> descriptions and \<t\> type.

